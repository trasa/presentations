Blackfin - SpringHelper:

This is the InstanceManager written by Scott Bellware for use with Spring.NET,
all of this code is his work.  The original Blackfin.SpringHelper was
decompiled from binary, now Scott has made the source available via SVN.  
Modifications to the source deal with supporting different versions of
Spring.NET, as well as minor changes to namespaces and other trivial things.

According to the Project page at http://code.google.com/p/instance-management/
this work is under the Apache 2.0 license, text is available here:
http://www.apache.org/licenses/LICENSE-2.0


Blackfin.SpringHelper.1.1.*.zip:
------------------------------------
This is built against the original source from Scott Bellware, at
http://code.google.com/p/instance-management/source
It is compiled against the Spring.NET 1.1 (final) release.



Blackfin.SpringHelper.1.1-RC2.*.zip:
------------------------------------
This is built against the original source from Scott Bellware, at
http://code.google.com/p/instance-management/source
It is compiled against the Spring.NET 1.1-RC2 release.


Blackfin.SpringHelper.1.0.*.zip:
----------------------
These files were decompiled using Reflection & a FileEmitter from the 
original binaries distributed by Scott Bellware.  These were built against
the Spring.NET 1.0 release.



