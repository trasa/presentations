Common.Logging, release 1.2.0 (October 10 2007)
---------------------------------------------------------
http://netcommon.sf.net/


1. INTRODUCTION

Provides a simple logging abstraction to switch between different logging implementations. 
There is current support for log4net (1.2.10 and 1.2.9), NLog and Enterprise Library logging 3.1

2. KNOWN ISSUES

No known issues

3. RELEASE INFO

Release contents:

* "bin" contains the Common.Logging distribution dll files
* "doc" contains reference documentation.

The Common Infrastructure Libraries for .NET are released under the terms of the Apache Software License (see license.txt).






