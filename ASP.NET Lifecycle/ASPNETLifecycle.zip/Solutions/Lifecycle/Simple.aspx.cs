using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Lifecycle {
	/// <summary>
	/// Summary description for Simple.
	/// </summary>
	public class Simple : System.Web.UI.Page {
		
		protected TextBox txt;
		protected DropDownList ddl;
		protected Button cmdSubmit;

		public Simple() {
			// connect to Init event via event registration.
			// compare to override OnInit method, below.
			this.Init += new EventHandler(Simple_Init);
		}

		private void Simple_Init(object sender, EventArgs e) {
			// at this point, all controls have their default values 
			// (defined in .aspx)
			Trace.Warn("Init", TextBoxValue);
			//this.ddl.SelectedIndexChanged += new EventHandler(ddl_SelectedIndexChanged);

			Trace.Warn("Init", DropDownListValue);
		}


		private void Page_Load(object sender, System.EventArgs e) {
			// at this point, ViewState & Postback data has been updated for 
			// each control in the tree.
			Trace.Warn("Page_Load", TextBoxValue);
			Trace.Warn("Page_Load", DropDownListValue);
		}


		#region Changed Events

		protected void txt_TextChanged(object sender, EventArgs e) {
			Trace.Warn("txt_TextChanged", TextBoxValue);
		}

		protected void ddl_SelectedIndexChanged(object sender, EventArgs e) {
			Trace.Warn("ddl_SelectedIndexChanged", DropDownListValue);
		}

		#endregion

		#region Postback Event

		protected void cmdSubmit_Click(object sender, EventArgs e) {
			Trace.Warn("cmdSubmit_Click", "Button Click Event");
		}

		#endregion

		#region helper stuff

		private string TextBoxValue { 
			get { return "txt.Text is '" + txt.Text + "'"; }
		}

		private string DropDownListValue {
			get { return "ddl.SelectedValue is '" + ddl.SelectedValue + "'"; }
		}

		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
